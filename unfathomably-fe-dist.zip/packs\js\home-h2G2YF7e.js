var e=`/packs/assets/home-DXU2sEny.svg`;export{e as t};
//# sourceMappingURL=home-h2G2YF7e.js.map