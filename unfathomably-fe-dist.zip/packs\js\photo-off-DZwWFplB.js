var e=`/packs/assets/photo-off-BPVaIhg-.svg`;export{e as t};
//# sourceMappingURL=photo-off-DZwWFplB.js.map