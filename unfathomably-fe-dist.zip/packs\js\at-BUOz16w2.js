var e=`/packs/assets/at-C0WNKalP.svg`;export{e as t};
//# sourceMappingURL=at-BUOz16w2.js.map