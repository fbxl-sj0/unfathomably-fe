var e=`/packs/assets/mail-_VDbtmXG.svg`;export{e as t};
//# sourceMappingURL=mail-Cc-O3nDb.js.map