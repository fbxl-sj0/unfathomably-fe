var e=`/packs/assets/chevron-left-BNrlRyF_.svg`;export{e as t};
//# sourceMappingURL=chevron-left-BiaRawm3.js.map