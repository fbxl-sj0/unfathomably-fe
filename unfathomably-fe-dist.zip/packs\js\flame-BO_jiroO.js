var e=`/packs/assets/flame-BSs9rGFY.svg`;export{e as t};
//# sourceMappingURL=flame-BO_jiroO.js.map