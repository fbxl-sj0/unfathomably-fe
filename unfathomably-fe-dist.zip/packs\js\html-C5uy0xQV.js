function e(e){let t=document.createElement(`div`);return t.innerHTML=e,[`.quote-inline`,`.recipients-inline`].forEach(e=>{t.querySelectorAll(e).forEach(e=>{e.remove()})}),t.innerHTML}function t(e){let t=document.createElement(`div`);t.innerHTML=e;let n=new Set([`address`,`article`,`aside`,`blockquote`,`div`,`footer`,`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`header`,`li`,`main`,`p`,`pre`,`section`]),r=``,i=()=>{!r||r.endsWith(`

`)||(r=r.replace(/\n*$/,``)+`

`)},a=e=>{if(e.nodeType===Node.TEXT_NODE){r+=e.textContent||``;return}if(!(e instanceof HTMLElement))return;let t=e.tagName.toLowerCase();if(t===`br`){r+=`
`;return}n.has(t)&&i(),e.childNodes.forEach(a)};return t.childNodes.forEach(a),r}export{e as n,t};
//# sourceMappingURL=html-C5uy0xQV.js.map