var e=`/packs/assets/clock-_bSidsxL.svg`;export{e as t};
//# sourceMappingURL=clock-DCDpWKrT.js.map