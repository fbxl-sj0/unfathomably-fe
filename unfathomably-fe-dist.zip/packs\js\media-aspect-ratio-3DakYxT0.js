var e=9/16,t=e=>isNaN(e)?!1:e>=10,n=t=>isNaN(t)?!1:t<=e,r=e=>isNaN(e)?!1:!t(e)&&!n(e);export{e as i,t as n,n as r,r as t};
//# sourceMappingURL=media-aspect-ratio-3DakYxT0.js.map