var e=`/packs/assets/chart-bar-CWbCVX3P.svg`;export{e as t};
//# sourceMappingURL=chart-bar-BBYy1wDL.js.map