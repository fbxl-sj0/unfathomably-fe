var e=`/packs/assets/pin-_369h2Ws.svg`;export{e as t};
//# sourceMappingURL=pin-Bi0iX8s-.js.map