var e=`/packs/assets/mood-smile-BbSo8J3Q.svg`;export{e as t};
//# sourceMappingURL=mood-smile-CPEfe8iQ.js.map