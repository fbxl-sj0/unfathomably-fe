var e=`/packs/assets/calendar-stats-LpTnWp3X.svg`;export{e as t};
//# sourceMappingURL=calendar-stats-DBVUUPOC.js.map