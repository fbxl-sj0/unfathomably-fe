var e=`/packs/assets/eye-Jk2ljAbr.svg`;export{e as t};
//# sourceMappingURL=eye-DgYWD64i.js.map