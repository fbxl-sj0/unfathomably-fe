var e=`SIDEBAR_OPEN`,t=`SIDEBAR_CLOSE`,n=()=>({type:e}),r=()=>({type:t});export{n as i,e as n,r,t};
//# sourceMappingURL=sidebar-DYg-2Apm.js.map