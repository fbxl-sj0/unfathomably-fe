var e=`/packs/assets/rss-MWyllM0J.svg`;export{e as t};
//# sourceMappingURL=rss-DZzTBbxv.js.map