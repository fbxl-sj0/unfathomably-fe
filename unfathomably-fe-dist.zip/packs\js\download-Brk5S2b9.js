var e=`/packs/assets/download-VfBDkq0q.svg`;export{e as t};
//# sourceMappingURL=download-Brk5S2b9.js.map