var e=`/packs/assets/alert-triangle-DL2fniGH.svg`;export{e as t};
//# sourceMappingURL=alert-triangle-Db2xqZKx.js.map