var e=`DROPDOWN_MENU_OPEN`,t=`DROPDOWN_MENU_CLOSE`,n=()=>({type:e}),r=()=>({type:t});export{n as i,e as n,r,t};
//# sourceMappingURL=dropdown-menu-DdUfPXYj.js.map