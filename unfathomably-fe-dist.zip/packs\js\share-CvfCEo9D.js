var e=`/packs/assets/share-DS22t7RL.svg`;export{e as t};
//# sourceMappingURL=share-CvfCEo9D.js.map