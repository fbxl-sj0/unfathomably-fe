var e=`/packs/assets/mood-happy-BJI2wmF_.svg`;export{e as t};
//# sourceMappingURL=mood-happy-BQnTVp8l.js.map