var e=`/packs/assets/circle-x-CK4U9E1a.svg`;export{e as t};
//# sourceMappingURL=circle-x-BX30Sw8Y.js.map