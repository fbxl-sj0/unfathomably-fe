var e=`/packs/assets/chevron-right-CKyvVyMk.svg`;export{e as t};
//# sourceMappingURL=chevron-right-CWoKIy9_.js.map