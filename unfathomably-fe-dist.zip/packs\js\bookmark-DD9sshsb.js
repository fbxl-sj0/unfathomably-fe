var e=`/packs/assets/bookmark-DyIvL60c.svg`;export{e as t};
//# sourceMappingURL=bookmark-DD9sshsb.js.map