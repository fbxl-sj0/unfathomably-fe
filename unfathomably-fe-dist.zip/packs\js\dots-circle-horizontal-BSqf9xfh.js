var e=`/packs/assets/dots-circle-horizontal-B_KE4zlp.svg`;export{e as t};
//# sourceMappingURL=dots-circle-horizontal-BSqf9xfh.js.map