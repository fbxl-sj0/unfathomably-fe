var e=`/packs/assets/arrow-left-D1wrvExj.svg`;export{e as t};
//# sourceMappingURL=arrow-left-DrDNNems.js.map