var e=`/packs/assets/player-play-CcBz62p3.svg`;export{e as t};
//# sourceMappingURL=player-play-COfYzEjg.js.map