var e;window.addEventListener(`message`,t=>{t.data?.type===`setHeight`&&(e=t.data?.id)});export{e as t};
//# sourceMappingURL=iframe-Ceh5Kv37.js.map