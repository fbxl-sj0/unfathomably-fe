var e=`/packs/assets/balloon-D-a4DcbV.svg`;export{e as t};
//# sourceMappingURL=balloon-BzAS4jhP.js.map