var e=`/packs/assets/circles-BSU2xvt9.svg`;export{e as t};
//# sourceMappingURL=circles-CUugyq3A.js.map