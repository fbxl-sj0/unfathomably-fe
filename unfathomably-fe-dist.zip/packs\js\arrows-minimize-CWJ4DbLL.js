var e=`/packs/assets/arrows-minimize-C53aklV5.svg`;export{e as t};
//# sourceMappingURL=arrows-minimize-CWJ4DbLL.js.map