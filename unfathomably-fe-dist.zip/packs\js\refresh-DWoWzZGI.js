var e=`/packs/assets/refresh-C3PWoPv0.svg`;export{e as t};
//# sourceMappingURL=refresh-DWoWzZGI.js.map