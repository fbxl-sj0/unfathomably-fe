var e=`/packs/assets/dots-Wv4MziBZ.svg`;export{e as t};
//# sourceMappingURL=dots-BnRd9clW.js.map