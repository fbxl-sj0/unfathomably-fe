var e=`/packs/assets/link-Cmy_BEZC.svg`;export{e as t};
//# sourceMappingURL=link-BTO-5j6J.js.map