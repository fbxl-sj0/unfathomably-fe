var e=()=>{throw Error(`This error is intentional.`)};export{e as default};
//# sourceMappingURL=intentional-error-D-E6i5-3.js.map