var e=`/packs/assets/calendar-event-DITplwPB.svg`;export{e as t};
//# sourceMappingURL=calendar-event--x794Yfu.js.map