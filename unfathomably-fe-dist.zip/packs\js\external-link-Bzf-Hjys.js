var e=`/packs/assets/external-link-DiYttYAh.svg`;export{e as t};
//# sourceMappingURL=external-link-Bzf-Hjys.js.map