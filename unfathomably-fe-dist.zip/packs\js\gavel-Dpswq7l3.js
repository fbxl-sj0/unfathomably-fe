var e=`/packs/assets/gavel-Bl8_3yNr.svg`;export{e as t};
//# sourceMappingURL=gavel-Dpswq7l3.js.map