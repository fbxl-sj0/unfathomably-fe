var e=`/packs/assets/bolt-DVqhsDet.svg`;export{e as t};
//# sourceMappingURL=bolt-BEl7NPwg.js.map