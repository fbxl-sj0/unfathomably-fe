var e=`/packs/assets/dots-vertical-heXif8nz.svg`;export{e as t};
//# sourceMappingURL=dots-vertical-D_OPdctN.js.map