var e=`/packs/assets/code-BgIjF-RL.svg`;export{e as t};
//# sourceMappingURL=code-p9BgWhnC.js.map