var e=`/packs/assets/hash-KhHFatL6.svg`;export{e as t};
//# sourceMappingURL=hash-DpZzp8kI.js.map