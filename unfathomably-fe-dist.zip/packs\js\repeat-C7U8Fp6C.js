var e=`/packs/assets/repeat-BYsbLWc2.svg`;export{e as t};
//# sourceMappingURL=repeat-C7U8Fp6C.js.map