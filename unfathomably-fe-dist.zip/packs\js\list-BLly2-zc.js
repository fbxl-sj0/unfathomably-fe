var e=`/packs/assets/list-yNx9ssJ8.svg`;export{e as t};
//# sourceMappingURL=list-BLly2-zc.js.map