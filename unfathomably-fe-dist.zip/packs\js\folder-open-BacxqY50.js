var e=`/packs/assets/folder-open-Buw9k8q3.svg`;export{e as t};
//# sourceMappingURL=folder-open-BacxqY50.js.map