var e=`/packs/assets/search-HdpEsCyp.svg`;export{e as t};
//# sourceMappingURL=search-Br1XPklQ.js.map