var e=`/packs/assets/quote-Dh-_rYPL.svg`;export{e as t};
//# sourceMappingURL=quote-BMqOL9K1.js.map