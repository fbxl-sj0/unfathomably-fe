var e=`/packs/assets/check-BH317kgg.svg`;export{e as t};
//# sourceMappingURL=check-DCUWqjSP.js.map