var e=`/packs/assets/ban-Caoi5s-W.svg`;export{e as t};
//# sourceMappingURL=ban-Bcy8MFf9.js.map