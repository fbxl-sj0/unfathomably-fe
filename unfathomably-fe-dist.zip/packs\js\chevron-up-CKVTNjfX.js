var e=`/packs/assets/chevron-up-BGeuZBBl.svg`;export{e as t};
//# sourceMappingURL=chevron-up-CKVTNjfX.js.map