var e=`/packs/assets/pinned-off-Ci-xfNl6.svg`;export{e as t};
//# sourceMappingURL=pinned-off-ocQSS42Z.js.map