var e=`/packs/assets/flag-gWHUHhFg.svg`;export{e as t};
//# sourceMappingURL=flag-C0viP0WD.js.map