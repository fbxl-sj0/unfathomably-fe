var e=`/packs/assets/briefcase-AvZPh8dg.svg`;export{e as t};
//# sourceMappingURL=briefcase-MjnYldYV.js.map