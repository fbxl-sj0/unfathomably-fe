import{qi as e}from"../index-U-BUGDzp.js";import{t}from"./react-C604Z0mM.js";import{t as n}from"./jsx-runtime-CbVCEGYz.js";import{t as r}from"./spinner-DkpPv5ZQ.js";var i=e(t()),a;(function(e){e[e.UP=-1]=`UP`,e[e.DOWN=1]=`DOWN`})(a||={});function o(e){var t=getComputedStyle(e).overflowY;return e===document.scrollingElement&&t===`visible`?!0:!(t!==`scroll`&&t!==`auto`)}function s(e,t){if(!o(e))return!1;if(t===a.DOWN)return e.scrollTop+e.clientHeight<e.scrollHeight;if(t===a.UP)return e.scrollTop>0;throw Error(`unsupported direction`)}function c(e,t){return s(e,t)?!0:e.parentElement==null?!1:c(e.parentElement,t)}function l(e,t){t===void 0&&(t={});var n=t.insertAt;if(!(!e||typeof document>`u`)){var r=document.head||document.getElementsByTagName(`head`)[0],i=document.createElement(`style`);i.type=`text/css`,n===`top`&&r.firstChild?r.insertBefore(i,r.firstChild):r.appendChild(i),i.styleSheet?i.styleSheet.cssText=e:i.appendChild(document.createTextNode(e))}}l(`.lds-ellipsis {
  display: inline-block;
  position: relative;
  width: 64px;
  height: 64px;
}

.lds-ellipsis div {
  position: absolute;
  top: 27px;
  width: 11px;
  height: 11px;
  border-radius: 50%;
  background: rgb(54, 54, 54);
  animation-timing-function: cubic-bezier(0, 1, 1, 0);
}

.lds-ellipsis div:nth-child(1) {
  left: 6px;
  animation: lds-ellipsis1 0.6s infinite;
}

.lds-ellipsis div:nth-child(2) {
  left: 6px;
  animation: lds-ellipsis2 0.6s infinite;
}

.lds-ellipsis div:nth-child(3) {
  left: 26px;
  animation: lds-ellipsis2 0.6s infinite;
}

.lds-ellipsis div:nth-child(4) {
  left: 45px;
  animation: lds-ellipsis3 0.6s infinite;
}

@keyframes lds-ellipsis1 {
  0% {
    transform: scale(0);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes lds-ellipsis3 {
  0% {
    transform: scale(1);
  }
  100% {
    transform: scale(0);
  }
}
@keyframes lds-ellipsis2 {
  0% {
    transform: translate(0, 0);
  }
  100% {
    transform: translate(19px, 0);
  }
}`);var u=function(){return i.createElement(`div`,{className:`lds-ellipsis`},i.createElement(`div`,null),i.createElement(`div`,null),i.createElement(`div`,null),i.createElement(`div`,null))},d=function(){return i.createElement(`div`,null,i.createElement(`p`,null,`↧\xA0\xA0pull to refresh\xA0\xA0↧`))};l(`.ptr,
.ptr__children {
  height: 100%;
  width: 100%;
  overflow: hidden;
  -webkit-overflow-scrolling: touch;
  position: relative;
}

.ptr.ptr--fetch-more-treshold-breached .ptr__fetch-more {
  display: block;
}

.ptr__fetch-more {
  display: none;
}

/**
  * Pull down transition 
  */
.ptr__children,
.ptr__pull-down {
  transition: transform 0.2s cubic-bezier(0, 0, 0.31, 1);
}

.ptr__pull-down {
  position: absolute;
  overflow: hidden;
  left: 0;
  right: 0;
  top: 0;
  visibility: hidden;
}
.ptr__pull-down > div {
  display: none;
}

.ptr--dragging {
  /**
    * Hide PullMore content is treshold breached
    */
}
.ptr--dragging.ptr--pull-down-treshold-breached .ptr__pull-down--pull-more {
  display: none;
}
.ptr--dragging {
  /**
    * Otherwize, display content
    */
}
.ptr--dragging .ptr__pull-down--pull-more {
  display: block;
}

.ptr--pull-down-treshold-breached {
  /**
    * Force opacity to 1 is pull down trashold breached
    */
}
.ptr--pull-down-treshold-breached .ptr__pull-down {
  opacity: 1 !important;
}
.ptr--pull-down-treshold-breached {
  /**
    * And display loader
    */
}
.ptr--pull-down-treshold-breached .ptr__pull-down--loading {
  display: block;
}

.ptr__loader {
  margin: 0 auto;
  text-align: center;
}`);var f=function(e){var t=e.isPullable,n=t===void 0?!0:t,r=e.canFetchMore,o=r===void 0?!1:r,s=e.onRefresh,l=e.onFetchMore,f=e.refreshingContent,p=f===void 0?i.createElement(u,null):f,m=e.pullingContent,h=m===void 0?i.createElement(d,null):m,g=e.children,_=e.pullDownThreshold,v=_===void 0?67:_,y=e.fetchMoreThreshold,b=y===void 0?100:y,x=e.maxPullDownDistance,S=x===void 0?95:x,C=e.resistance,w=C===void 0?1:C,T=e.backgroundColor,E=e.className,D=E===void 0?``:E,O=(0,i.useRef)(null),k=(0,i.useRef)(null),A=(0,i.useRef)(null),j=(0,i.useRef)(null),M=!1,N=!1,P=!1,F=0,I=0;(0,i.useEffect)(function(){if(!(!n||!k||!k.current)){var e=k.current;return e.addEventListener(`touchstart`,z,{passive:!0}),e.addEventListener(`mousedown`,z),e.addEventListener(`touchmove`,B,{passive:!1}),e.addEventListener(`mousemove`,B),window.addEventListener(`scroll`,V),e.addEventListener(`touchend`,H),e.addEventListener(`mouseup`,H),document.body.addEventListener(`mouseleave`,H),function(){e.removeEventListener(`touchstart`,z),e.removeEventListener(`mousedown`,z),e.removeEventListener(`touchmove`,B),e.removeEventListener(`mousemove`,B),window.removeEventListener(`scroll`,V),e.removeEventListener(`touchend`,H),e.removeEventListener(`mouseup`,H),document.body.removeEventListener(`mouseleave`,H)}}},[g,n,s,v,S,o,b]),(0,i.useEffect)(function(){O?.current&&(O.current.classList.contains(`ptr--fetch-more-treshold-breached`)||o&&L()<b&&l&&(O.current.classList.add(`ptr--fetch-more-treshold-breached`),N=!0,l().then(R).catch(R)))},[o,g]);var L=function(){if(!k||!k.current)return-1;var e=window.scrollY;return k.current.scrollHeight-e-window.innerHeight},R=function(){requestAnimationFrame(function(){k.current&&(k.current.style.overflowX=`hidden`,k.current.style.overflowY=`auto`,k.current.style.transform=`unset`),A.current&&(A.current.style.opacity=`0`),O.current&&(O.current.classList.remove(`ptr--pull-down-treshold-breached`),O.current.classList.remove(`ptr--dragging`),O.current.classList.remove(`ptr--fetch-more-treshold-breached`)),M&&=!1,N&&=!1})},z=function(e){P=!1,e instanceof MouseEvent&&(F=e.pageY),window.TouchEvent&&e instanceof TouchEvent&&(F=e.touches[0].pageY),I=F,!(e.type===`touchstart`&&c(e.target,a.UP))&&(k.current.getBoundingClientRect().top<0||(P=!0))},B=function(e){if(P){if(I=window.TouchEvent&&e instanceof TouchEvent?e.touches[0].pageY:e.pageY,O.current.classList.add(`ptr--dragging`),I<F){P=!1;return}e.cancelable&&e.preventDefault();var t=Math.min((I-F)/w,S);t>=v&&(P=!0,M=!0,O.current.classList.remove(`ptr--dragging`),O.current.classList.add(`ptr--pull-down-treshold-breached`)),!(t>=S)&&(A.current.style.opacity=(t/65).toString(),k.current.style.overflow=`visible`,k.current.style.transform=`translate(0px, `+t+`px)`,A.current.style.visibility=`visible`)}},V=function(e){N||o&&L()<b&&l&&(N=!0,O.current.classList.add(`ptr--fetch-more-treshold-breached`),l().then(R).catch(R))},H=function(){if(P=!1,F=0,I=0,!M){A.current&&(A.current.style.visibility=`hidden`),R();return}k.current&&(k.current.style.overflow=`visible`,k.current.style.transform=`translate(0px, `+v+`px)`),s().then(R).catch(R)};return i.createElement(`div`,{className:`ptr `+D,style:{backgroundColor:T},ref:O},i.createElement(`div`,{className:`ptr__pull-down`,ref:A},i.createElement(`div`,{className:`ptr__loader ptr__pull-down--loading`},p),i.createElement(`div`,{className:`ptr__pull-down--pull-more`},h)),i.createElement(`div`,{className:`ptr__children`,ref:k},g,i.createElement(`div`,{className:`ptr__fetch-more`,ref:j},i.createElement(`div`,{className:`ptr__loader ptr__fetch-more--loading`},p))))},p=n(),m=({children:e,onRefresh:t,...n})=>(0,p.jsx)(f,{onRefresh:()=>t?t():Promise.resolve(),pullingContent:(0,p.jsx)(p.Fragment,{}),refreshingContent:t?(0,p.jsx)(r,{size:30,withText:!1}):(0,p.jsx)(p.Fragment,{}),pullDownThreshold:67,maxPullDownDistance:95,resistance:2,...n,children:(0,p.jsx)(p.Fragment,{children:e})});export{m as t};
//# sourceMappingURL=pull-to-refresh-2t6c02vm.js.map