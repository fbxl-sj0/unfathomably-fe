var e=`/packs/assets/pencil-BkWtcb1d.svg`;export{e as t};
//# sourceMappingURL=pencil-uZpYvrOb.js.map