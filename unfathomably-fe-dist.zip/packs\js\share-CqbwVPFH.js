import{t as e}from"./jsx-runtime-CbVCEGYz.js";import{i as t,l as n}from"./react-router-dom-SCKHA9LJ.js";import{t as r}from"./useAppDispatch-D6k7GKFL.js";import{_t as i}from"./compose-_ffrjYNE.js";var a=e(),o=()=>{let e=r(),{search:o}=n(),s=new URLSearchParams(o),c=[s.get(`title`),s.get(`text`),s.get(`url`)].filter(e=>e).join(`

`);return c&&e(i(`compose-modal`,c)),(0,a.jsx)(t,{to:`/`})};export{o as default};
//# sourceMappingURL=share-CqbwVPFH.js.map