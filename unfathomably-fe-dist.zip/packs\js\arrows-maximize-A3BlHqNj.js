var e=`/packs/assets/arrows-maximize-DLWfc4pi.svg`;export{e as t};
//# sourceMappingURL=arrows-maximize-A3BlHqNj.js.map