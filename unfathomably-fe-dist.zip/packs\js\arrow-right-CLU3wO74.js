var e=`/packs/assets/arrow-right-njj8Fx9e.svg`;export{e as t};
//# sourceMappingURL=arrow-right-CLU3wO74.js.map