var e=`/packs/assets/edit-BT1bM1-X.svg`;export{e as t};
//# sourceMappingURL=edit-DrZNCIJp.js.map