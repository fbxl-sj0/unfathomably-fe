var e=`/packs/assets/lock-DEETnH9X.svg`;export{e as t};
//# sourceMappingURL=lock-BxA3_hPt.js.map