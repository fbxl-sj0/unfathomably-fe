var e=`/packs/assets/plus-CHjVNGJj.svg`;export{e as t};
//# sourceMappingURL=plus-Bm4ilmkY.js.map