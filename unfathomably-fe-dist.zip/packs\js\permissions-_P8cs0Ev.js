var e=1048576,t=(e,t)=>!0;export{t as n,e as t};
//# sourceMappingURL=permissions-_P8cs0Ev.js.map