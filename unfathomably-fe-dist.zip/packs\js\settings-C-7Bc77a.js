var e=`/packs/assets/settings-D9GwxiUX.svg`;export{e as t};
//# sourceMappingURL=settings-C-7Bc77a.js.map