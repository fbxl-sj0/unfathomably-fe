var e=`/packs/assets/calendar-BHKlYJL7.svg`;export{e as t};
//# sourceMappingURL=calendar-C16SWAvB.js.map