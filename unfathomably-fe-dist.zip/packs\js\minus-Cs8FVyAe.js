var e=`/packs/assets/minus-CgIeXl5o.svg`;export{e as t};
//# sourceMappingURL=minus-Cs8FVyAe.js.map