var e=`/packs/assets/message-2-CMODyilN.svg`;export{e as t};
//# sourceMappingURL=message-2-Dwx6LPVZ.js.map