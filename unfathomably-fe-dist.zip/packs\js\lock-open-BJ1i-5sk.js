var e=`/packs/assets/lock-open-COGb0jvQ.svg`;export{e as t};
//# sourceMappingURL=lock-open-BJ1i-5sk.js.map