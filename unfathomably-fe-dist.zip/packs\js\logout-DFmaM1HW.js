var e=`/packs/assets/logout-b4aM6mQX.svg`;export{e as t};
//# sourceMappingURL=logout-DFmaM1HW.js.map