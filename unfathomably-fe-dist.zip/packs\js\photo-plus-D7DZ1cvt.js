var e=`/packs/assets/photo-plus-Bg3Y2irb.svg`;export{e as t};
//# sourceMappingURL=photo-plus-D7DZ1cvt.js.map