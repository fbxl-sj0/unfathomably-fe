var e=`/packs/assets/backspace-Mem99cwN.svg`;export{e as t};
//# sourceMappingURL=backspace-C-C2r-7m.js.map