var e=`/packs/assets/map-pin-Dcuh9o8E.svg`;export{e as t};
//# sourceMappingURL=map-pin-CVWd9Tz4.js.map