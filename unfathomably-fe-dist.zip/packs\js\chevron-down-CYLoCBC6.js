var e=`/packs/assets/chevron-down-CNCACQ8G.svg`;export{e as t};
//# sourceMappingURL=chevron-down-CYLoCBC6.js.map